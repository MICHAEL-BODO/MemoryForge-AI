# MemoryForge-AI Production Deployment Package

This package contains production-ready deployment configuration following DevOps best practices.

## 📁 Deployment Files

### 1. Dockerfile
```dockerfile
# MemoryForge-AI Production Dockerfile
FROM python:3.13-slim

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    build-essential \
    git \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements first for better caching
COPY requirements.txt requirements-prod.txt ./

# Install Python dependencies
RUN pip install --no-cache-dir -r requirements.txt && \
    pip install --no-cache-dir -r requirements-prod.txt

# Copy application code
COPY phase1_hybrid_memory/ ./phase1_hybrid_memory/
COPY phase1_archival_complete.py ./
COPY phase2_mcp_server_complete.py ./
COPY phase3_content_ingestion_complete.py ./
COPY phase4_nl_interface_complete.py ./

# Create data directories
RUN mkdir -p /app/data/chroma_db /app/data/uploads /app/logs

# Set environment variables
ENV PYTHONUNBUFFERED=1 \
    MEMORYFORGE_DATA_DIR=/app/data \
    MEMORYFORGE_LOG_LEVEL=INFO

# Expose MCP server port
EXPOSE 8000

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD python -c "import requests; requests.get('http://localhost:8000/health')"

# Run MCP server
CMD ["python", "phase2_mcp_server_complete.py"]
```

### 2. docker-compose.yml
```yaml
version: '3.8'

services:
  memoryforge:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: memoryforge-ai
    ports:
      - "8000:8000"
    volumes:
      - memoryforge_data:/app/data
      - memoryforge_logs:/app/logs
      - ./config:/app/config:ro
    environment:
      - MEMORYFORGE_DATA_DIR=/app/data
      - MEMORYFORGE_LOG_LEVEL=INFO
      - TOKEN_LIMIT=190000
      - ARCHIVAL_THRESHOLD_HOURS=24
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "python", "-c", "import requests; requests.get('http://localhost:8000/health')"]
      interval: 30s
      timeout: 10s
      retries: 3
    networks:
      - memoryforge_network

  # Optional: Redis for caching
  redis:
    image: redis:7-alpine
    container_name: memoryforge-redis
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: unless-stopped
    networks:
      - memoryforge_network

  # Optional: Prometheus for monitoring
  prometheus:
    image: prom/prometheus:latest
    container_name: memoryforge-prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
    restart: unless-stopped
    networks:
      - memoryforge_network

volumes:
  memoryforge_data:
  memoryforge_logs:
  redis_data:
  prometheus_data:

networks:
  memoryforge_network:
    driver: bridge
```

### 3. requirements-prod.txt
```
# Production dependencies
gunicorn==21.2.0
uvicorn[standard]==0.27.0
redis==5.0.1
prometheus-client==0.19.0
sentry-sdk==1.40.0
python-dotenv==1.0.0
```

### 4. GitHub Actions CI/CD Pipeline
```yaml
# .github/workflows/ci-cd.yml
name: MemoryForge-AI CI/CD

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.10', '3.11', '3.12', '3.13']

    steps:
    - uses: actions/checkout@v4
    
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v5
      with:
        python-version: ${{ matrix.python-version }}
    
    - name: Cache pip packages
      uses: actions/cache@v4
      with:
        path: ~/.cache/pip
        key: ${{ runner.os }}-pip-${{ hashFiles('requirements.txt') }}
        restore-keys: |
          ${{ runner.os }}-pip-
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
        pip install pytest pytest-cov pytest-asyncio
    
    - name: Run tests
      run: |
        pytest test_all_phases_integration.py -v --cov=. --cov-report=xml
    
    - name: Upload coverage
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage.xml
        fail_ci_if_error: false

  lint:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    
    - name: Set up Python
      uses: actions/setup-python@v5
      with:
        python-version: '3.13'
    
    - name: Install linting tools
      run: |
        pip install black flake8 mypy pylint
    
    - name: Run Black
      run: black --check .
    
    - name: Run Flake8
      run: flake8 . --max-line-length=100 --exclude=venv,__pycache__
    
    - name: Run MyPy
      run: mypy . --ignore-missing-imports

  build:
    runs-on: ubuntu-latest
    needs: [test, lint]
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Set up Docker Buildx
      uses: docker/setup-buildx-action@v3
    
    - name: Login to Docker Hub
      uses: docker/login-action@v3
      with:
        username: ${{ secrets.DOCKER_USERNAME }}
        password: ${{ secrets.DOCKER_PASSWORD }}
    
    - name: Build and push
      uses: docker/build-push-action@v5
      with:
        context: .
        push: true
        tags: |
          ${{ secrets.DOCKER_USERNAME }}/memoryforge-ai:latest
          ${{ secrets.DOCKER_USERNAME }}/memoryforge-ai:${{ github.sha }}
        cache-from: type=registry,ref=${{ secrets.DOCKER_USERNAME }}/memoryforge-ai:buildcache
        cache-to: type=registry,ref=${{ secrets.DOCKER_USERNAME }}/memoryforge-ai:buildcache,mode=max

  deploy:
    runs-on: ubuntu-latest
    needs: build
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    
    steps:
    - uses: actions/checkout@v4
    
    - name: Deploy to production
      env:
        DEPLOY_KEY: ${{ secrets.DEPLOY_KEY }}
        DEPLOY_HOST: ${{ secrets.DEPLOY_HOST }}
      run: |
        echo "$DEPLOY_KEY" > deploy_key
        chmod 600 deploy_key
        ssh -i deploy_key -o StrictHostKeyChecking=no $DEPLOY_HOST << 'EOF'
          cd /opt/memoryforge-ai
          docker-compose pull
          docker-compose up -d
          docker-compose ps
        EOF
```

### 5. Kubernetes Deployment (Optional)
```yaml
# k8s/deployment.yml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: memoryforge-ai
  labels:
    app: memoryforge-ai
spec:
  replicas: 3
  selector:
    matchLabels:
      app: memoryforge-ai
  template:
    metadata:
      labels:
        app: memoryforge-ai
    spec:
      containers:
      - name: memoryforge
        image: your-registry/memoryforge-ai:latest
        ports:
        - containerPort: 8000
        env:
        - name: MEMORYFORGE_DATA_DIR
          value: "/app/data"
        - name: TOKEN_LIMIT
          value: "190000"
        volumeMounts:
        - name: data
          mountPath: /app/data
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
      volumes:
      - name: data
        persistentVolumeClaim:
          claimName: memoryforge-data-pvc
---
apiVersion: v1
kind: Service
metadata:
  name: memoryforge-service
spec:
  selector:
    app: memoryforge-ai
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8000
  type: LoadBalancer
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: memoryforge-data-pvc
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 10Gi
```

### 6. Prometheus Monitoring Configuration
```yaml
# monitoring/prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'memoryforge-ai'
    static_configs:
      - targets: ['memoryforge:8000']
    metrics_path: '/metrics'
```

### 7. Environment Configuration
```bash
# .env.example
# Copy to .env and fill in values

# Application
MEMORYFORGE_DATA_DIR=/app/data
MEMORYFORGE_LOG_LEVEL=INFO
TOKEN_LIMIT=190000
ARCHIVAL_THRESHOLD_HOURS=24

# MCP Server
MCP_SERVER_HOST=0.0.0.0
MCP_SERVER_PORT=8000

# Archival Settings
COMPRESSION_RATIO=0.3
TOKEN_PRESSURE_THRESHOLD=0.7
MIN_IMPORTANCE_RETENTION=0.6

# Content Ingestion
WATCH_DIRECTORIES=/app/data/uploads
SUPPORTED_EXTENSIONS=.txt,.md,.pdf,.docx,.xlsx,.pptx

# Monitoring
SENTRY_DSN=your-sentry-dsn
PROMETHEUS_ENABLED=true

# Redis (optional)
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_DB=0
```

### 8. Makefile for Easy Commands
```makefile
# Makefile
.PHONY: help build test run stop clean deploy

help:
	@echo "MemoryForge-AI Deployment Commands"
	@echo "  make build    - Build Docker image"
	@echo "  make test     - Run tests"
	@echo "  make run      - Start services"
	@echo "  make stop     - Stop services"
	@echo "  make clean    - Clean up"
	@echo "  make deploy   - Deploy to production"

build:
	docker-compose build

test:
	pytest test_all_phases_integration.py -v

run:
	docker-compose up -d
	@echo "MemoryForge-AI is running at http://localhost:8000"

stop:
	docker-compose down

clean:
	docker-compose down -v
	rm -rf data/ logs/

deploy:
	@echo "Deploying to production..."
	./scripts/deploy.sh

logs:
	docker-compose logs -f memoryforge

status:
	docker-compose ps
```

## 🚀 Deployment Instructions

### Local Development
```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run tests
pytest test_all_phases_integration.py -v

# 3. Start server locally
python phase2_mcp_server_complete.py
```

### Docker Deployment
```bash
# 1. Build and start
make build
make run

# 2. Check status
make status

# 3. View logs
make logs

# 4. Stop
make stop
```

### Production Deployment
```bash
# 1. Set environment variables
cp .env.example .env
# Edit .env with production values

# 2. Build and deploy
make deploy

# 3. Monitor
docker-compose logs -f
```

## 📊 Monitoring & Health Checks

### Health Endpoints
- `/health` - Basic health check
- `/ready` - Readiness probe
- `/metrics` - Prometheus metrics

### Logging
Logs are stored in `/app/logs/` and follow structured format:
```json
{
  "timestamp": "2026-01-16T10:30:00Z",
  "level": "INFO",
  "component": "archival_pipeline",
  "message": "Archived 15 memories",
  "metadata": {"archived_count": 15, "token_pressure": 0.75}
}
```

## 🔒 Security Best Practices

1. **Environment Variables**: Never commit secrets
2. **Container Security**: Run as non-root user
3. **Network**: Use internal networks for services
4. **Data**: Encrypt sensitive data at rest
5. **Monitoring**: Set up alerts for anomalies

## 📈 Scaling Considerations

### Horizontal Scaling
- Use Kubernetes for auto-scaling
- Redis for distributed caching
- Shared volume for ChromaDB

### Vertical Scaling
- Increase memory for larger embedding models
- Add CPU cores for parallel processing
- SSD storage for faster vector operations

## 🔄 Backup & Recovery

```bash
# Backup data
docker run --rm \
  -v memoryforge_data:/data \
  -v $(pwd)/backups:/backups \
  alpine tar czf /backups/backup-$(date +%Y%m%d).tar.gz /data

# Restore data
docker run --rm \
  -v memoryforge_data:/data \
  -v $(pwd)/backups:/backups \
  alpine tar xzf /backups/backup-20260116.tar.gz -C /
```
