"""
Comprehensive Integration Tests for MemoryForge-AI
Tests all 4 phases together with professional testing patterns
"""

import pytest
import tempfile
import shutil
from pathlib import Path
from datetime import datetime
import json

# Phase 1 imports
from phase1_hybrid_memory.memory_models import MemoryEntry, MemoryMetadata, MemoryTier
from phase1_hybrid_memory.vector_store import VectorStore
from phase1_archival_complete import ArchivalPipeline, MemoryCompressor, ArchivalScheduler

# Phase 2 imports
# from phase2_mcp_server_complete import (would import in real project)

# Phase 3 imports
from phase3_content_ingestion_complete import (
    ContentExtractor, FileWatcher, ContentIngestionPipeline, batch_ingest_directory
)

# Phase 4 imports
from phase4_nl_interface_complete import (
    NaturalLanguageMemoryInterface, Intent, IntentClassifier, QueryParser
)


class TestPhase1ArchivalPipeline:
    """Test Phase 1: Archival Pipeline"""
    
    @pytest.fixture
    def temp_db(self):
        """Create temporary database"""
        temp_dir = tempfile.mkdtemp()
        yield temp_dir
        shutil.rmtree(temp_dir)
    
    @pytest.fixture
    def vector_store(self, temp_db):
        """Create vector store"""
        return VectorStore(persist_directory=temp_db)
    
    def test_memory_compressor(self):
        """Test memory compression"""
        compressor = MemoryCompressor(compression_ratio=0.3)
        
        content = """
        This is a very long memory that needs to be compressed. 
        Machine learning is a subset of artificial intelligence.
        Deep learning uses neural networks with multiple layers.
        Natural language processing enables computers to understand text.
        The field is advancing rapidly with new breakthroughs.
        """
        
        compressed = compressor.compress_extractive(content, max_sentences=3)
        
        assert len(compressed) < len(content)
        assert "Machine learning" in compressed or "Deep learning" in compressed
        
        stats = compressor.get_stats()
        assert stats['total_compressed'] == 1
        assert stats['total_saved_tokens'] > 0
    
    def test_archival_scheduler_scoring(self):
        """Test archival score calculation"""
        scheduler = ArchivalScheduler()
        
        # Old, unused, low importance = low score (high priority)
        score1 = scheduler.calculate_archival_score(
            age_hours=48.0,
            access_count=0,
            importance_score=0.2,
            token_pressure=0.8
        )
        
        # Recent, frequently used, high importance = high score (low priority)
        score2 = scheduler.calculate_archival_score(
            age_hours=1.0,
            access_count=20,
            importance_score=0.9,
            token_pressure=0.4
        )
        
        assert score1 < score2  # Lower score = higher archival priority
    
    def test_archival_pipeline_integration(self, vector_store):
        """Test complete archival pipeline"""
        pipeline = ArchivalPipeline(vector_store)
        
        # Add test memories
        for i in range(5):
            entry = MemoryEntry(
                content=f"Test memory {i}",
                metadata=MemoryMetadata(
                    topics=[f"topic{i}"],
                    importance_score=0.3
                )
            )
            vector_store.add_memory(entry)
        
        # Run archival cycle
        result = pipeline.run_archival_cycle(
            current_token_usage=150000,
            token_limit=190000,
            compress=True
        )
        
        assert result['status'] in ['completed', 'skipped']
        
        stats = pipeline.get_pipeline_stats()
        assert 'pipeline' in stats
        assert 'compression' in stats


class TestPhase3ContentIngestion:
    """Test Phase 3: Content Ingestion"""
    
    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory"""
        temp_dir = tempfile.mkdtemp()
        yield Path(temp_dir)
        shutil.rmtree(temp_dir)
    
    @pytest.fixture
    def vector_store(self):
        """Create vector store"""
        temp_db = tempfile.mkdtemp()
        store = VectorStore(persist_directory=temp_db)
        yield store
        shutil.rmtree(temp_db)
    
    def test_text_extraction(self, temp_dir):
        """Test text file extraction"""
        extractor = ContentExtractor()
        
        # Create test file
        test_file = temp_dir / "test.txt"
        test_file.write_text("This is a test document with important content.")
        
        result = extractor.extract(test_file)
        
        assert 'content' in result
        assert "important content" in result['content']
        assert result['metadata']['type'] == 'text'
    
    def test_json_extraction(self, temp_dir):
        """Test JSON extraction"""
        extractor = ContentExtractor()
        
        test_file = temp_dir / "test.json"
        data = {"name": "test", "value": 42, "nested": {"key": "value"}}
        test_file.write_text(json.dumps(data))
        
        result = extractor.extract(test_file)
        
        assert 'content' in result
        assert 'structured_data' in result
        assert result['structured_data']['value'] == 42
    
    def test_file_watcher_pattern_matching(self):
        """Test file watcher filtering"""
        watcher = FileWatcher(callback=lambda x, y: None)
        
        # Should process
        assert watcher.should_process(Path("document.txt"))
        assert watcher.should_process(Path("code.py"))
        assert watcher.should_process(Path("data.json"))
        
        # Should not process
        assert not watcher.should_process(Path(".git/config"))
        assert not watcher.should_process(Path("node_modules/package.json"))
        assert not watcher.should_process(Path("file.exe"))
    
    def test_batch_ingestion(self, temp_dir, vector_store):
        """Test batch directory ingestion"""
        # Create test files
        (temp_dir / "file1.txt").write_text("Content 1")
        (temp_dir / "file2.txt").write_text("Content 2")
        (temp_dir / "file3.md").write_text("# Markdown content")
        
        stats = batch_ingest_directory(
            directory=str(temp_dir),
            vector_store=vector_store,
            recursive=False
        )
        
        assert stats['total_files'] == 3
        assert stats['processed'] > 0
        assert stats['memories_created'] > 0


class TestPhase4NLInterface:
    """Test Phase 4: Natural Language Interface"""
    
    @pytest.fixture
    def vector_store(self):
        """Create vector store"""
        temp_db = tempfile.mkdtemp()
        store = VectorStore(persist_directory=temp_db)
        yield store
        shutil.rmtree(temp_db)
    
    def test_intent_classification(self):
        """Test intent classifier"""
        classifier = IntentClassifier()
        
        # Test REMEMBER intent
        intent, conf = classifier.classify("Remember that Python is awesome")
        assert intent == Intent.REMEMBER
        assert conf > 0
        
        # Test RECALL intent
        intent, conf = classifier.classify("What do you remember about Python?")
        assert intent == Intent.RECALL
        assert conf > 0
        
        # Test SEARCH intent
        intent, conf = classifier.classify("Search for memories about machine learning")
        assert intent == Intent.SEARCH
        assert conf > 0
        
        # Test STATUS intent
        intent, conf = classifier.classify("Show me memory statistics")
        assert intent == Intent.STATUS
        assert conf > 0
    
    def test_query_parser(self):
        """Test query parsing"""
        parser = QueryParser()
        classifier = IntentClassifier()
        
        # Parse REMEMBER query
        intent, conf = classifier.classify("Remember that AI is important #technology")
        parsed = parser.parse("Remember that AI is important #technology", intent, conf)
        
        assert parsed.intent == Intent.REMEMBER
        assert 'technology' in parsed.topics
        assert parsed.importance == 0.5  # default
    
    def test_nl_interface_remember(self, vector_store):
        """Test remembering through NL interface"""
        interface = NaturalLanguageMemoryInterface(vector_store)
        
        result = interface.process("Remember that Python 3.13 was released in 2024")
        
        assert result['status'] == 'success'
        assert 'memory_id' in result
        assert result['parsed']['intent'] == 'remember'
    
    def test_nl_interface_recall(self, vector_store):
        """Test recall through NL interface"""
        interface = NaturalLanguageMemoryInterface(vector_store)
        
        # First remember something
        interface.process("Remember that TensorFlow is a machine learning library")
        
        # Then recall it
        result = interface.process("What do you know about TensorFlow?")
        
        assert result['status'] == 'success'
        assert result['parsed']['intent'] == 'recall'
    
    def test_nl_interface_status(self, vector_store):
        """Test status through NL interface"""
        interface = NaturalLanguageMemoryInterface(vector_store)
        
        result = interface.process("Show me memory statistics")
        
        assert result['status'] == 'success'
        assert 'stats' in result
        assert result['parsed']['intent'] == 'status'


class TestFullIntegration:
    """Test complete system integration"""
    
    @pytest.fixture
    def system(self):
        """Create complete system"""
        temp_db = tempfile.mkdtemp()
        temp_watch = tempfile.mkdtemp()
        
        # Initialize all components
        store = VectorStore(persist_directory=temp_db)
        archival = ArchivalPipeline(store)
        ingestion = ContentIngestionPipeline(store, [temp_watch])
        nl_interface = NaturalLanguageMemoryInterface(store)
        
        yield {
            'store': store,
            'archival': archival,
            'ingestion': ingestion,
            'nl_interface': nl_interface,
            'temp_db': temp_db,
            'temp_watch': temp_watch
        }
        
        shutil.rmtree(temp_db)
        shutil.rmtree(temp_watch)
    
    def test_end_to_end_workflow(self, system):
        """Test complete workflow: Ingest -> Store -> Search -> Archive"""
        
        # 1. Add memory via NL interface
        result = system['nl_interface'].process(
            "Remember that Claude is an AI assistant created by Anthropic"
        )
        assert result['status'] == 'success'
        memory_id = result['memory_id']
        
        # 2. Search for it
        result = system['nl_interface'].process(
            "What do you know about Anthropic?"
        )
        assert result['status'] == 'success'
        assert len(result['results']) > 0
        
        # 3. Get statistics
        result = system['nl_interface'].process("Show me memory statistics")
        assert result['status'] == 'success'
        assert result['stats']['total_count'] > 0
        
        # 4. Run archival (even if nothing gets archived)
        archival_result = system['archival'].run_archival_cycle(
            current_token_usage=100000,
            token_limit=190000,
            compress=True
        )
        assert archival_result['status'] in ['completed', 'skipped']
    
    def test_content_ingestion_to_search(self, system):
        """Test ingesting file and searching it"""
        # Create test file
        test_file = Path(system['temp_watch']) / "important.txt"
        test_file.write_text("Quantum computing uses quantum mechanics for computation")
        
        # Batch ingest
        stats = batch_ingest_directory(
            directory=system['temp_watch'],
            vector_store=system['store'],
            recursive=False
        )
        
        assert stats['processed'] > 0
        
        # Search for it
        result = system['nl_interface'].process(
            "What do you know about quantum computing?"
        )
        
        assert result['status'] == 'success'


# Performance tests
class TestPerformance:
    """Performance benchmarks"""
    
    @pytest.fixture
    def vector_store(self):
        """Create vector store"""
        temp_db = tempfile.mkdtemp()
        store = VectorStore(persist_directory=temp_db)
        yield store
        shutil.rmtree(temp_db)
    
    def test_bulk_memory_insertion(self, vector_store):
        """Test inserting many memories"""
        import time
        
        start = time.time()
        
        for i in range(100):
            entry = MemoryEntry(
                content=f"Test memory number {i} with some content",
                metadata=MemoryMetadata(topics=[f"topic{i % 10}"])
            )
            vector_store.add_memory(entry)
        
        elapsed = time.time() - start
        
        assert elapsed < 30  # Should complete in under 30 seconds
        print(f"\nInserted 100 memories in {elapsed:.2f}s ({elapsed/100*1000:.1f}ms per memory)")
    
    def test_search_performance(self, vector_store):
        """Test search speed"""
        import time
        
        # Add some memories
        for i in range(50):
            entry = MemoryEntry(
                content=f"Memory about topic {i % 5} with relevant content",
                metadata=MemoryMetadata(topics=[f"topic{i % 5}"])
            )
            vector_store.add_memory(entry)
        
        # Test search speed
        start = time.time()
        results = vector_store.search("topic content", limit=10)
        elapsed = time.time() - start
        
        assert elapsed < 0.5  # Should be fast
        print(f"\nSearch completed in {elapsed*1000:.1f}ms")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
