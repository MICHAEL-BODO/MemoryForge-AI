"""
Phase 3: Content Ingestion System - COMPLETE IMPLEMENTATION
Monitors file systems and automatically ingests content into memory system
"""

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from pathlib import Path
from typing import List, Dict, Optional, Set
from datetime import datetime
import mimetypes
import hashlib
import json

# Content extraction imports
try:
    from PyPDF2 import PdfReader
    from docx import Document
    from openpyxl import load_workbook
    from pptx import Presentation
except ImportError:
    print("Warning: Some content extractors not available. Install PyPDF2, python-docx, openpyxl, python-pptx")


class ContentExtractor:
    """Extracts text content from various file types"""
    
    def __init__(self):
        self.supported_types = {
            '.txt': self.extract_text,
            '.md': self.extract_text,
            '.py': self.extract_text,
            '.js': self.extract_text,
            '.ts': self.extract_text,
            '.json': self.extract_json,
            '.pdf': self.extract_pdf,
            '.docx': self.extract_docx,
            '.xlsx': self.extract_xlsx,
            '.pptx': self.extract_pptx,
        }
        
        self.extraction_stats = {
            'total_files': 0,
            'successful': 0,
            'failed': 0,
            'by_type': {}
        }
    
    def extract_text(self, filepath: Path) -> Dict[str, any]:
        """Extract text from plain text files"""
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            return {
                'content': content,
                'metadata': {
                    'type': 'text',
                    'encoding': 'utf-8',
                    'size': len(content),
                    'lines': content.count('\n') + 1
                }
            }
        except Exception as e:
            return {'error': str(e)}
    
    def extract_json(self, filepath: Path) -> Dict[str, any]:
        """Extract structured data from JSON files"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Convert JSON to readable text
            content = json.dumps(data, indent=2)
            
            return {
                'content': content,
                'structured_data': data,
                'metadata': {
                    'type': 'json',
                    'keys': list(data.keys()) if isinstance(data, dict) else None
                }
            }
        except Exception as e:
            return {'error': str(e)}
    
    def extract_pdf(self, filepath: Path) -> Dict[str, any]:
        """Extract text from PDF files"""
        try:
            reader = PdfReader(filepath)
            
            text_parts = []
            for i, page in enumerate(reader.pages):
                text = page.extract_text()
                if text.strip():
                    text_parts.append(f"[Page {i+1}]\n{text}")
            
            content = "\n\n".join(text_parts)
            
            return {
                'content': content,
                'metadata': {
                    'type': 'pdf',
                    'pages': len(reader.pages),
                    'size': len(content)
                }
            }
        except Exception as e:
            return {'error': str(e)}
    
    def extract_docx(self, filepath: Path) -> Dict[str, any]:
        """Extract text from Word documents"""
        try:
            doc = Document(filepath)
            
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            content = "\n\n".join(paragraphs)
            
            return {
                'content': content,
                'metadata': {
                    'type': 'docx',
                    'paragraphs': len(paragraphs),
                    'size': len(content)
                }
            }
        except Exception as e:
            return {'error': str(e)}
    
    def extract_xlsx(self, filepath: Path) -> Dict[str, any]:
        """Extract text from Excel spreadsheets"""
        try:
            workbook = load_workbook(filepath, data_only=True)
            
            sheets_data = []
            for sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]
                
                rows = []
                for row in sheet.iter_rows(values_only=True):
                    row_text = " | ".join([str(cell) if cell is not None else "" for cell in row])
                    if row_text.strip():
                        rows.append(row_text)
                
                if rows:
                    sheets_data.append(f"[Sheet: {sheet_name}]\n" + "\n".join(rows))
            
            content = "\n\n".join(sheets_data)
            
            return {
                'content': content,
                'metadata': {
                    'type': 'xlsx',
                    'sheets': len(sheets_data),
                    'size': len(content)
                }
            }
        except Exception as e:
            return {'error': str(e)}
    
    def extract_pptx(self, filepath: Path) -> Dict[str, any]:
        """Extract text from PowerPoint presentations"""
        try:
            prs = Presentation(filepath)
            
            slides_text = []
            for i, slide in enumerate(prs.slides):
                slide_parts = [f"[Slide {i+1}]"]
                
                for shape in slide.shapes:
                    if hasattr(shape, "text") and shape.text.strip():
                        slide_parts.append(shape.text)
                
                if len(slide_parts) > 1:
                    slides_text.append("\n".join(slide_parts))
            
            content = "\n\n".join(slides_text)
            
            return {
                'content': content,
                'metadata': {
                    'type': 'pptx',
                    'slides': len(slides_text),
                    'size': len(content)
                }
            }
        except Exception as e:
            return {'error': str(e)}
    
    def extract(self, filepath: Path) -> Dict[str, any]:
        """Extract content from a file"""
        self.extraction_stats['total_files'] += 1
        
        suffix = filepath.suffix.lower()
        if suffix not in self.supported_types:
            self.extraction_stats['failed'] += 1
            return {'error': f'Unsupported file type: {suffix}'}
        
        # Track by type
        if suffix not in self.extraction_stats['by_type']:
            self.extraction_stats['by_type'][suffix] = {'success': 0, 'failed': 0}
        
        extractor = self.supported_types[suffix]
        result = extractor(filepath)
        
        if 'error' in result:
            self.extraction_stats['failed'] += 1
            self.extraction_stats['by_type'][suffix]['failed'] += 1
        else:
            self.extraction_stats['successful'] += 1
            self.extraction_stats['by_type'][suffix]['success'] += 1
        
        return result
    
    def get_stats(self) -> Dict[str, any]:
        """Get extraction statistics"""
        return self.extraction_stats.copy()


class FileWatcher(FileSystemEventHandler):
    """Watches file system for changes and triggers ingestion"""
    
    def __init__(self, 
                 callback,
                 watch_extensions: Optional[Set[str]] = None,
                 ignore_patterns: Optional[Set[str]] = None):
        """
        Args:
            callback: Function to call when file changes detected
            watch_extensions: Set of extensions to watch (e.g., {'.txt', '.pdf'})
            ignore_patterns: Set of patterns to ignore (e.g., {'.git', '__pycache__'})
        """
        super().__init__()
        self.callback = callback
        self.watch_extensions = watch_extensions or {
            '.txt', '.md', '.py', '.js', '.ts', '.json',
            '.pdf', '.docx', '.xlsx', '.pptx'
        }
        self.ignore_patterns = ignore_patterns or {
            '.git', '__pycache__', 'node_modules', '.venv', 'venv',
            '.DS_Store', 'Thumbs.db'
        }
        
        self.processed_files = {}  # filepath -> last_hash
        self.event_count = 0
    
    def should_process(self, filepath: Path) -> bool:
        """Check if file should be processed"""
        # Check if ignored
        for pattern in self.ignore_patterns:
            if pattern in str(filepath):
                return False
        
        # Check extension
        if filepath.suffix.lower() not in self.watch_extensions:
            return False
        
        return True
    
    def get_file_hash(self, filepath: Path) -> str:
        """Get MD5 hash of file content"""
        try:
            with open(filepath, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except:
            return None
    
    def on_created(self, event):
        """Handle file creation"""
        if event.is_directory:
            return
        
        filepath = Path(event.src_path)
        if not self.should_process(filepath):
            return
        
        self.event_count += 1
        self.callback('created', filepath)
    
    def on_modified(self, event):
        """Handle file modification"""
        if event.is_directory:
            return
        
        filepath = Path(event.src_path)
        if not self.should_process(filepath):
            return
        
        # Check if file actually changed (avoid duplicate events)
        file_hash = self.get_file_hash(filepath)
        if file_hash and filepath in self.processed_files:
            if self.processed_files[filepath] == file_hash:
                return  # No actual change
        
        self.processed_files[filepath] = file_hash
        self.event_count += 1
        self.callback('modified', filepath)
    
    def on_deleted(self, event):
        """Handle file deletion"""
        if event.is_directory:
            return
        
        filepath = Path(event.src_path)
        if filepath in self.processed_files:
            del self.processed_files[filepath]
        
        self.event_count += 1
        self.callback('deleted', filepath)


class ContentIngestionPipeline:
    """Main pipeline orchestrating file watching and content extraction"""
    
    def __init__(self, 
                 vector_store,
                 watch_paths: List[str],
                 extractor: Optional[ContentExtractor] = None):
        """
        Args:
            vector_store: VectorStore instance for storing memories
            watch_paths: List of directory paths to watch
            extractor: Optional content extractor (creates default if None)
        """
        self.vector_store = vector_store
        self.watch_paths = [Path(p) for p in watch_paths]
        self.extractor = extractor or ContentExtractor()
        
        self.watcher = FileWatcher(callback=self.process_file_event)
        self.observer = None
        
        self.ingestion_stats = {
            'files_processed': 0,
            'memories_created': 0,
            'errors': 0,
            'started_at': None,
            'is_running': False
        }
    
    def process_file_event(self, event_type: str, filepath: Path):
        """Process a file system event"""
        try:
            if event_type == 'deleted':
                # Could implement memory deletion here
                return
            
            # Extract content
            extraction = self.extractor.extract(filepath)
            
            if 'error' in extraction:
                self.ingestion_stats['errors'] += 1
                print(f"Extraction error for {filepath}: {extraction['error']}")
                return
            
            # Create memory from extracted content
            from phase1_hybrid_memory.memory_models import MemoryEntry, MemoryMetadata
            
            entry = MemoryEntry(
                content=extraction['content'],
                metadata=MemoryMetadata(
                    topics=[filepath.suffix[1:], 'file_ingestion'],
                    tags=[event_type, str(filepath.parent.name)],
                    source=f"file_watcher:{filepath.name}",
                    importance_score=0.5
                )
            )
            
            memory_id = self.vector_store.add_memory(entry)
            
            self.ingestion_stats['files_processed'] += 1
            self.ingestion_stats['memories_created'] += 1
            
            print(f"Ingested {filepath.name} -> memory {memory_id[:8]}...")
            
        except Exception as e:
            self.ingestion_stats['errors'] += 1
            print(f"Error processing {filepath}: {e}")
    
    def start(self):
        """Start watching file systems"""
        if self.ingestion_stats['is_running']:
            return
        
        self.observer = Observer()
        
        for path in self.watch_paths:
            if path.exists():
                self.observer.schedule(self.watcher, str(path), recursive=True)
                print(f"Watching: {path}")
        
        self.observer.start()
        self.ingestion_stats['is_running'] = True
        self.ingestion_stats['started_at'] = datetime.now()
        
        print("Content ingestion pipeline started")
    
    def stop(self):
        """Stop watching file systems"""
        if not self.ingestion_stats['is_running']:
            return
        
        if self.observer:
            self.observer.stop()
            self.observer.join()
        
        self.ingestion_stats['is_running'] = False
        print("Content ingestion pipeline stopped")
    
    def get_stats(self) -> Dict[str, any]:
        """Get pipeline statistics"""
        stats = self.ingestion_stats.copy()
        stats['extraction_stats'] = self.extractor.get_stats()
        stats['watcher_events'] = self.watcher.event_count
        return stats


# ============================================================================
# BATCH INGESTION UTILITY
# ============================================================================

def batch_ingest_directory(directory: str, 
                           vector_store,
                           recursive: bool = True,
                           extensions: Optional[Set[str]] = None) -> Dict[str, any]:
    """
    Batch ingest all files from a directory
    
    Args:
        directory: Directory path to ingest
        vector_store: VectorStore instance
        recursive: Whether to recurse into subdirectories
        extensions: Set of extensions to process (None = all supported)
    
    Returns:
        Statistics dictionary
    """
    extractor = ContentExtractor()
    dir_path = Path(directory)
    
    if not dir_path.exists():
        return {'error': 'Directory not found'}
    
    stats = {
        'total_files': 0,
        'processed': 0,
        'memories_created': 0,
        'errors': []
    }
    
    # Get all files
    pattern = "**/*" if recursive else "*"
    all_files = list(dir_path.glob(pattern))
    
    for filepath in all_files:
        if not filepath.is_file():
            continue
        
        if extensions and filepath.suffix.lower() not in extensions:
            continue
        
        stats['total_files'] += 1
        
        try:
            # Extract content
            extraction = extractor.extract(filepath)
            
            if 'error' in extraction:
                stats['errors'].append(f"{filepath.name}: {extraction['error']}")
                continue
            
            # Create memory
            from phase1_hybrid_memory.memory_models import MemoryEntry, MemoryMetadata
            
            entry = MemoryEntry(
                content=extraction['content'],
                metadata=MemoryMetadata(
                    topics=[filepath.suffix[1:], 'batch_ingestion'],
                    tags=['batch', str(filepath.parent.name)],
                    source=f"batch_ingest:{filepath.name}",
                    importance_score=0.5
                )
            )
            
            memory_id = vector_store.add_memory(entry)
            stats['processed'] += 1
            stats['memories_created'] += 1
            
            print(f"Ingested: {filepath.name}")
            
        except Exception as e:
            stats['errors'].append(f"{filepath.name}: {str(e)}")
    
    return stats
