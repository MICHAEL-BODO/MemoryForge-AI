"""
MemoryForge-AI MCP Server - COMPLETE IMPLEMENTATION
FastMCP server providing memory management tools for LLMs
"""

from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, Field, field_validator, ConfigDict
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum
import json
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import MemoryForge components
try:
    from phase1_hybrid_memory.memory_models import MemoryEntry, MemoryMetadata, MemoryTier
    from phase1_hybrid_memory.embedding_generator import EmbeddingGenerator
    from phase1_hybrid_memory.vector_store import VectorStore
    from phase1_archival_complete import ArchivalPipeline, MemoryCompressor, ArchivalScheduler
except ImportError as e:
    print(f"Warning: Could not import MemoryForge components: {e}")
    print("Server will run but some features may be limited")

# Initialize MCP server
mcp = FastMCP("memoryforge_mcp")

# Global instances (initialized on first use)
_vector_store = None
_embedding_generator = None
_archival_pipeline = None

def get_vector_store():
    """Lazy initialization of vector store"""
    global _vector_store
    if _vector_store is None:
        _vector_store = VectorStore(persist_directory="./memoryforge_data")
    return _vector_store

def get_embedding_generator():
    """Lazy initialization of embedding generator"""
    global _embedding_generator
    if _embedding_generator is None:
        _embedding_generator = EmbeddingGenerator()
    return _embedding_generator

def get_archival_pipeline():
    """Lazy initialization of archival pipeline"""
    global _archival_pipeline
    if _archival_pipeline is None:
        store = get_vector_store()
        _archival_pipeline = ArchivalPipeline(
            vector_store=store,
            compressor=MemoryCompressor(),
            scheduler=ArchivalScheduler()
        )
    return _archival_pipeline


# ============================================================================
# PYDANTIC INPUT MODELS
# ============================================================================

class AddMemoryInput(BaseModel):
    """Input for adding a new memory"""
    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)
    
    content: str = Field(..., description="Memory content to store", min_length=1, max_length=10000)
    topics: Optional[List[str]] = Field(default_factory=list, description="Topics/categories for the memory", max_items=20)
    tags: Optional[List[str]] = Field(default_factory=list, description="Tags for filtering", max_items=20)
    importance_score: Optional[float] = Field(default=0.5, description="Importance score (0.0 to 1.0)", ge=0.0, le=1.0)
    source: Optional[str] = Field(default="user_conversation", description="Source of the memory")

class SearchMemoryInput(BaseModel):
    """Input for searching memories"""
    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)
    
    query: str = Field(..., description="Search query text", min_length=1, max_length=1000)
    limit: Optional[int] = Field(default=5, description="Maximum number of results", ge=1, le=50)
    min_similarity: Optional[float] = Field(default=0.3, description="Minimum similarity threshold", ge=0.0, le=1.0)
    tier: Optional[str] = Field(default=None, description="Search specific tier: 'tier1', 'tier2', or None for both")

class UpdateMemoryInput(BaseModel):
    """Input for updating memory metadata"""
    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)
    
    memory_id: str = Field(..., description="UUID of the memory to update", min_length=36, max_length=36)
    importance_score: Optional[float] = Field(default=None, description="New importance score", ge=0.0, le=1.0)
    topics: Optional[List[str]] = Field(default=None, description="New topics list", max_items=20)
    tags: Optional[List[str]] = Field(default=None, description="New tags list", max_items=20)

class DeleteMemoryInput(BaseModel):
    """Input for deleting a memory"""
    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)
    
    memory_id: str = Field(..., description="UUID of the memory to delete", min_length=36, max_length=36)

class MoveTierInput(BaseModel):
    """Input for moving memory between tiers"""
    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)
    
    memory_id: str = Field(..., description="UUID of the memory to move", min_length=36, max_length=36)
    target_tier: str = Field(..., description="Target tier: 'tier1' or 'tier2'", pattern="^(tier1|tier2)$")

class ArchivalCycleInput(BaseModel):
    """Input for running archival cycle"""
    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)
    
    current_token_usage: int = Field(..., description="Current token usage", ge=0)
    token_limit: int = Field(default=190000, description="Token limit", ge=1000)
    compress: Optional[bool] = Field(default=True, description="Whether to compress archived memories")

class GetStatsInput(BaseModel):
    """Input for getting memory statistics"""
    model_config = ConfigDict(str_strip_whitespace=True, validate_assignment=True)
    
    include_archival_log: Optional[bool] = Field(default=False, description="Include archival log in stats")


# ============================================================================
# MCP TOOLS
# ============================================================================

@mcp.tool(
    name="memoryforge_add_memory",
    annotations={
        "title": "Add New Memory",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False
    }
)
async def add_memory(params: AddMemoryInput) -> str:
    """Add a new memory to the MemoryForge system.
    
    This tool stores new information in the hybrid memory system with semantic
    embeddings for efficient retrieval. Memories are initially stored in Tier 1
    (active memory) and may be automatically archived to Tier 2 based on usage patterns.
    
    Args:
        params (AddMemoryInput): Memory content and metadata including:
            - content (str): The memory content to store
            - topics (List[str]): Topics/categories for organization
            - tags (List[str]): Tags for filtering
            - importance_score (float): Importance rating 0.0-1.0
            - source (str): Source identifier
    
    Returns:
        str: JSON response with memory_id and confirmation
    """
    try:
        store = get_vector_store()
        
        # Create memory entry
        entry = MemoryEntry(
            content=params.content,
            metadata=MemoryMetadata(
                topics=params.topics,
                tags=params.tags,
                importance_score=params.importance_score,
                source=params.source
            )
        )
        
        # Add to vector store
        memory_id = store.add_memory(entry)
        
        result = {
            "status": "success",
            "memory_id": memory_id,
            "tier": "tier1_active",
            "topics": params.topics,
            "importance": params.importance_score
        }
        
        return json.dumps(result, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
            "error_type": type(e).__name__
        }, indent=2)


@mcp.tool(
    name="memoryforge_search",
    annotations={
        "title": "Search Memories",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def search_memories(params: SearchMemoryInput) -> str:
    """Search for relevant memories using semantic similarity.
    
    This tool performs semantic search across stored memories using embedding-based
    similarity. Results are ranked by relevance score and filtered by the specified
    minimum similarity threshold.
    
    Args:
        params (SearchMemoryInput): Search parameters including:
            - query (str): The search query text
            - limit (int): Maximum number of results (1-50)
            - min_similarity (float): Minimum similarity threshold
            - tier (str): Specific tier to search or None for both
    
    Returns:
        str: JSON response with ranked search results
    """
    try:
        store = get_vector_store()
        
        # Perform search
        results = store.search(
            query=params.query,
            limit=params.limit,
            tier=params.tier
        )
        
        # Filter by similarity threshold
        filtered_results = [
            (entry, score) for entry, score in results 
            if score >= params.min_similarity
        ]
        
        # Format results
        formatted_results = []
        for entry, score in filtered_results:
            formatted_results.append({
                "memory_id": entry.id,
                "content": entry.content,
                "similarity_score": round(score, 4),
                "tier": entry.metadata.tier.value,
                "topics": entry.metadata.topics,
                "tags": entry.metadata.tags,
                "importance": entry.metadata.importance_score,
                "created_at": entry.metadata.created_at.isoformat(),
                "access_count": entry.metadata.access_count
            })
        
        response = {
            "status": "success",
            "query": params.query,
            "total_results": len(formatted_results),
            "results": formatted_results
        }
        
        return json.dumps(response, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
            "error_type": type(e).__name__
        }, indent=2)


@mcp.tool(
    name="memoryforge_delete",
    annotations={
        "title": "Delete Memory",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def delete_memory(params: DeleteMemoryInput) -> str:
    """Delete a memory from the system permanently.
    
    This tool permanently removes a memory from both Tier 1 and Tier 2 storage.
    This operation cannot be undone.
    
    Args:
        params (DeleteMemoryInput): Contains memory_id to delete
    
    Returns:
        str: JSON response confirming deletion
    """
    try:
        store = get_vector_store()
        
        # Delete from both tiers
        success = store.delete_memory(params.memory_id)
        
        if success:
            return json.dumps({
                "status": "success",
                "memory_id": params.memory_id,
                "message": "Memory deleted successfully"
            }, indent=2)
        else:
            return json.dumps({
                "status": "error",
                "message": "Memory not found"
            }, indent=2)
            
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
            "error_type": type(e).__name__
        }, indent=2)


@mcp.tool(
    name="memoryforge_move_tier",
    annotations={
        "title": "Move Memory Between Tiers",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def move_memory_tier(params: MoveTierInput) -> str:
    """Move a memory between Tier 1 (active) and Tier 2 (persistent).
    
    This tool manually moves memories between storage tiers. Use Tier 1 for
    frequently accessed memories and Tier 2 for archived/historical data.
    
    Args:
        params (MoveTierInput): Memory ID and target tier
    
    Returns:
        str: JSON response confirming tier movement
    """
    try:
        store = get_vector_store()
        
        if params.target_tier == "tier2":
            success = store.move_to_tier2(params.memory_id)
        else:
            # Would implement move_to_tier1 if needed
            return json.dumps({
                "status": "error",
                "message": "Moving to Tier 1 not yet implemented"
            }, indent=2)
        
        if success:
            return json.dumps({
                "status": "success",
                "memory_id": params.memory_id,
                "new_tier": params.target_tier,
                "message": f"Memory moved to {params.target_tier}"
            }, indent=2)
        else:
            return json.dumps({
                "status": "error",
                "message": "Failed to move memory"
            }, indent=2)
            
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
            "error_type": type(e).__name__
        }, indent=2)


@mcp.tool(
    name="memoryforge_run_archival",
    annotations={
        "title": "Run Archival Cycle",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False
    }
)
async def run_archival_cycle(params: ArchivalCycleInput) -> str:
    """Execute an automatic archival cycle to manage memory tiers.
    
    This tool analyzes current memory usage and automatically archives old or
    less-important memories from Tier 1 to Tier 2. It helps maintain optimal
    performance by keeping active memory lean.
    
    Args:
        params (ArchivalCycleInput): Token usage info and compression settings
    
    Returns:
        str: JSON response with archival results and statistics
    """
    try:
        pipeline = get_archival_pipeline()
        
        # Run archival cycle
        result = pipeline.run_archival_cycle(
            current_token_usage=params.current_token_usage,
            token_limit=params.token_limit,
            compress=params.compress
        )
        
        return json.dumps(result, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
            "error_type": type(e).__name__
        }, indent=2)


@mcp.tool(
    name="memoryforge_get_stats",
    annotations={
        "title": "Get Memory Statistics",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False
    }
)
async def get_memory_stats(params: GetStatsInput) -> str:
    """Get comprehensive statistics about the memory system.
    
    This tool provides detailed statistics including memory counts per tier,
    token usage, archival history, and system health metrics.
    
    Args:
        params (GetStatsInput): Configuration for stats retrieval
    
    Returns:
        str: JSON response with complete system statistics
    """
    try:
        store = get_vector_store()
        stats = store.get_stats()
        
        response = {
            "status": "success",
            "timestamp": datetime.now().isoformat(),
            "memory_stats": stats
        }
        
        # Add archival log if requested
        if params.include_archival_log:
            pipeline = get_archival_pipeline()
            pipeline_stats = pipeline.get_pipeline_stats()
            response["archival_stats"] = pipeline_stats
        
        return json.dumps(response, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
            "error_type": type(e).__name__
        }, indent=2)


# ============================================================================
# SERVER STARTUP
# ============================================================================

if __name__ == "__main__":
    # Run the MCP server
    mcp.run()
