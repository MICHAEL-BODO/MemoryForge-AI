"""
Phase 4: Natural Language Memory Interface - COMPLETE IMPLEMENTATION
Provides natural language interface for memory operations
"""

from typing import Dict, List, Optional, Tuple
from enum import Enum
from dataclasses import dataclass
import re


class Intent(Enum):
    """Memory operation intents"""
    REMEMBER = "remember"  # Store new memory
    RECALL = "recall"      # Search/retrieve memories
    FORGET = "forget"      # Delete memory
    ARCHIVE = "archive"    # Move to Tier 2
    SEARCH = "search"      # Semantic search
    LIST = "list"          # List memories
    STATUS = "status"      # Get system status
    UNKNOWN = "unknown"    # Cannot determine intent


@dataclass
class ParsedQuery:
    """Parsed natural language query"""
    intent: Intent
    content: Optional[str] = None
    topics: List[str] = None
    tags: List[str] = None
    importance: Optional[float] = None
    memory_id: Optional[str] = None
    filters: Dict[str, any] = None
    confidence: float = 0.0
    
    def __post_init__(self):
        if self.topics is None:
            self.topics = []
        if self.tags is None:
            self.tags = []
        if self.filters is None:
            self.filters = {}


class IntentClassifier:
    """Classifies natural language queries into memory operation intents"""
    
    def __init__(self):
        self.intent_patterns = {
            Intent.REMEMBER: [
                r'\b(remember|save|store|keep|record|note)\b',
                r'\b(don\'t forget|make a note)\b',
                r'\b(add to memory|memorize)\b'
            ],
            Intent.RECALL: [
                r'\b(recall|retrieve|find|get|show me|what did)\b.*\b(memory|memories|remember)\b',
                r'\b(do you remember|have you stored)\b',
                r'\b(what do you know about)\b'
            ],
            Intent.FORGET: [
                r'\b(forget|delete|remove|erase|clear)\b',
                r'\b(get rid of|discard)\b'
            ],
            Intent.ARCHIVE: [
                r'\b(archive|move to archive|store long-term)\b',
                r'\b(put in|move to).*\b(archive|tier 2|persistent)\b'
            ],
            Intent.SEARCH: [
                r'\b(search|find|look for|query)\b',
                r'\b(show me|give me|list).*\b(about|related to|containing)\b'
            ],
            Intent.LIST: [
                r'\b(list|show|display).*\b(all|my|recent)\b.*\b(memories|memory)\b',
                r'\b(what.*stored|what.*remembered)\b'
            ],
            Intent.STATUS: [
                r'\b(status|stats|statistics|how many|count)\b',
                r'\b(memory usage|storage|capacity)\b',
                r'\b(system.*status|health)\b'
            ]
        }
        
        self.classification_stats = {
            'total_queries': 0,
            'by_intent': {intent: 0 for intent in Intent}
        }
    
    def classify(self, query: str) -> Tuple[Intent, float]:
        """
        Classify query intent
        
        Args:
            query: Natural language query
            
        Returns:
            Tuple of (Intent, confidence_score)
        """
        self.classification_stats['total_queries'] += 1
        
        query_lower = query.lower()
        scores = {intent: 0.0 for intent in Intent}
        
        # Score each intent based on pattern matches
        for intent, patterns in self.intent_patterns.items():
            for pattern in patterns:
                if re.search(pattern, query_lower):
                    scores[intent] += 1.0
        
        # Get best scoring intent
        if max(scores.values()) == 0:
            self.classification_stats['by_intent'][Intent.UNKNOWN] += 1
            return Intent.UNKNOWN, 0.0
        
        best_intent = max(scores.items(), key=lambda x: x[1])[0]
        confidence = scores[best_intent] / len(self.intent_patterns[best_intent])
        
        self.classification_stats['by_intent'][best_intent] += 1
        
        return best_intent, min(confidence, 1.0)
    
    def get_stats(self) -> Dict[str, any]:
        """Get classification statistics"""
        return self.classification_stats.copy()


class QueryParser:
    """Parses natural language queries to extract structured information"""
    
    def __init__(self):
        self.topic_indicators = [
            r'about\s+([a-z0-9_\-]+)',
            r'regarding\s+([a-z0-9_\-]+)',
            r'on\s+([a-z0-9_\-]+)',
            r'related to\s+([a-z0-9_\-]+)'
        ]
        
        self.importance_indicators = {
            'critical': 1.0,
            'very important': 0.9,
            'important': 0.8,
            'somewhat important': 0.6,
            'normal': 0.5,
            'low priority': 0.3,
            'trivial': 0.2
        }
    
    def extract_topics(self, query: str) -> List[str]:
        """Extract topics from query"""
        query_lower = query.lower()
        topics = []
        
        for pattern in self.topic_indicators:
            matches = re.findall(pattern, query_lower)
            topics.extend(matches)
        
        # Also extract hashtags
        hashtags = re.findall(r'#(\w+)', query)
        topics.extend(hashtags)
        
        return list(set(topics))  # Remove duplicates
    
    def extract_importance(self, query: str) -> float:
        """Extract importance score from query"""
        query_lower = query.lower()
        
        for phrase, score in self.importance_indicators.items():
            if phrase in query_lower:
                return score
        
        return 0.5  # Default
    
    def extract_memory_id(self, query: str) -> Optional[str]:
        """Extract memory ID if present (UUID pattern)"""
        # Look for UUID pattern
        uuid_pattern = r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
        match = re.search(uuid_pattern, query.lower())
        
        if match:
            return match.group(0)
        
        return None
    
    def extract_content(self, query: str, intent: Intent) -> Optional[str]:
        """Extract main content from query based on intent"""
        if intent == Intent.REMEMBER:
            # Remove command words and extract what to remember
            cleaned = re.sub(r'\b(remember|save|store|keep|that|this)\b', '', query, flags=re.IGNORECASE)
            cleaned = cleaned.strip()
            return cleaned if cleaned else None
        
        elif intent in [Intent.RECALL, Intent.SEARCH]:
            # Extract search query
            cleaned = re.sub(r'\b(find|search for|recall|show me|memories about)\b', '', query, flags=re.IGNORECASE)
            cleaned = cleaned.strip()
            return cleaned if cleaned else None
        
        return None
    
    def parse(self, query: str, intent: Intent, confidence: float) -> ParsedQuery:
        """
        Parse query into structured format
        
        Args:
            query: Natural language query
            intent: Classified intent
            confidence: Classification confidence
            
        Returns:
            ParsedQuery object
        """
        return ParsedQuery(
            intent=intent,
            content=self.extract_content(query, intent),
            topics=self.extract_topics(query),
            importance=self.extract_importance(query),
            memory_id=self.extract_memory_id(query),
            confidence=confidence
        )


class OperationHandler:
    """Handles memory operations based on parsed queries"""
    
    def __init__(self, vector_store):
        """
        Args:
            vector_store: VectorStore instance
        """
        self.vector_store = vector_store
        self.operation_stats = {
            'total_operations': 0,
            'by_intent': {intent: 0 for intent in Intent},
            'successful': 0,
            'failed': 0
        }
    
    def handle(self, parsed: ParsedQuery) -> Dict[str, any]:
        """
        Execute memory operation
        
        Args:
            parsed: ParsedQuery object
            
        Returns:
            Operation result
        """
        self.operation_stats['total_operations'] += 1
        self.operation_stats['by_intent'][parsed.intent] += 1
        
        try:
            if parsed.intent == Intent.REMEMBER:
                result = self._handle_remember(parsed)
            elif parsed.intent == Intent.RECALL:
                result = self._handle_recall(parsed)
            elif parsed.intent == Intent.SEARCH:
                result = self._handle_search(parsed)
            elif parsed.intent == Intent.FORGET:
                result = self._handle_forget(parsed)
            elif parsed.intent == Intent.ARCHIVE:
                result = self._handle_archive(parsed)
            elif parsed.intent == Intent.LIST:
                result = self._handle_list(parsed)
            elif parsed.intent == Intent.STATUS:
                result = self._handle_status(parsed)
            else:
                result = {
                    'status': 'error',
                    'message': 'Unable to determine what you want me to do'
                }
            
            if result.get('status') == 'success':
                self.operation_stats['successful'] += 1
            else:
                self.operation_stats['failed'] += 1
            
            return result
            
        except Exception as e:
            self.operation_stats['failed'] += 1
            return {
                'status': 'error',
                'message': f'Operation failed: {str(e)}'
            }
    
    def _handle_remember(self, parsed: ParsedQuery) -> Dict[str, any]:
        """Handle REMEMBER intent"""
        if not parsed.content:
            return {
                'status': 'error',
                'message': 'What would you like me to remember?'
            }
        
        from phase1_hybrid_memory.memory_models import MemoryEntry, MemoryMetadata
        
        entry = MemoryEntry(
            content=parsed.content,
            metadata=MemoryMetadata(
                topics=parsed.topics,
                importance_score=parsed.importance or 0.5,
                source="natural_language_interface"
            )
        )
        
        memory_id = self.vector_store.add_memory(entry)
        
        return {
            'status': 'success',
            'operation': 'remember',
            'memory_id': memory_id,
            'message': f'I\'ve remembered: "{parsed.content[:50]}..."'
        }
    
    def _handle_recall(self, parsed: ParsedQuery) -> Dict[str, any]:
        """Handle RECALL intent"""
        if not parsed.content:
            return {
                'status': 'error',
                'message': 'What would you like me to recall?'
            }
        
        results = self.vector_store.search(parsed.content, limit=5)
        
        if not results:
            return {
                'status': 'success',
                'operation': 'recall',
                'results': [],
                'message': 'I don\'t have any memories matching that query'
            }
        
        formatted_results = [
            {
                'content': entry.content,
                'similarity': round(score, 3),
                'topics': entry.metadata.topics,
                'created': entry.metadata.created_at.strftime('%Y-%m-%d %H:%M')
            }
            for entry, score in results
        ]
        
        return {
            'status': 'success',
            'operation': 'recall',
            'results': formatted_results,
            'message': f'Found {len(results)} relevant memories'
        }
    
    def _handle_search(self, parsed: ParsedQuery) -> Dict[str, any]:
        """Handle SEARCH intent"""
        return self._handle_recall(parsed)  # Same as recall
    
    def _handle_forget(self, parsed: ParsedQuery) -> Dict[str, any]:
        """Handle FORGET intent"""
        if not parsed.memory_id:
            return {
                'status': 'error',
                'message': 'Please specify which memory to forget (provide memory ID)'
            }
        
        success = self.vector_store.delete_memory(parsed.memory_id)
        
        if success:
            return {
                'status': 'success',
                'operation': 'forget',
                'memory_id': parsed.memory_id,
                'message': 'Memory deleted successfully'
            }
        else:
            return {
                'status': 'error',
                'message': 'Memory not found'
            }
    
    def _handle_archive(self, parsed: ParsedQuery) -> Dict[str, any]:
        """Handle ARCHIVE intent"""
        if not parsed.memory_id:
            return {
                'status': 'error',
                'message': 'Please specify which memory to archive (provide memory ID)'
            }
        
        success = self.vector_store.move_to_tier2(parsed.memory_id)
        
        if success:
            return {
                'status': 'success',
                'operation': 'archive',
                'memory_id': parsed.memory_id,
                'message': 'Memory archived to Tier 2'
            }
        else:
            return {
                'status': 'error',
                'message': 'Failed to archive memory'
            }
    
    def _handle_list(self, parsed: ParsedQuery) -> Dict[str, any]:
        """Handle LIST intent"""
        stats = self.vector_store.get_stats()
        
        return {
            'status': 'success',
            'operation': 'list',
            'stats': stats,
            'message': f'You have {stats["total_count"]} total memories ({stats["tier1_count"]} active, {stats["tier2_count"]} archived)'
        }
    
    def _handle_status(self, parsed: ParsedQuery) -> Dict[str, any]:
        """Handle STATUS intent"""
        stats = self.vector_store.get_stats()
        
        return {
            'status': 'success',
            'operation': 'status',
            'stats': stats,
            'message': 'Memory system is operational'
        }
    
    def get_stats(self) -> Dict[str, any]:
        """Get operation statistics"""
        return self.operation_stats.copy()


class NaturalLanguageMemoryInterface:
    """Complete natural language interface for memory system"""
    
    def __init__(self, vector_store):
        """
        Args:
            vector_store: VectorStore instance
        """
        self.classifier = IntentClassifier()
        self.parser = QueryParser()
        self.handler = OperationHandler(vector_store)
    
    def process(self, query: str) -> Dict[str, any]:
        """
        Process a natural language query
        
        Args:
            query: Natural language query string
            
        Returns:
            Operation result with status and message
        """
        # Classify intent
        intent, confidence = self.classifier.classify(query)
        
        # Parse query
        parsed = self.parser.parse(query, intent, confidence)
        
        # Handle operation
        result = self.handler.handle(parsed)
        
        # Add parsed query info to result
        result['parsed'] = {
            'intent': intent.value,
            'confidence': round(confidence, 3),
            'topics': parsed.topics,
            'importance': parsed.importance
        }
        
        return result
    
    def get_stats(self) -> Dict[str, any]:
        """Get complete interface statistics"""
        return {
            'classifier': self.classifier.get_stats(),
            'handler': self.handler.get_stats()
        }


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_nl_interface(vector_store) -> NaturalLanguageMemoryInterface:
    """Create a natural language memory interface"""
    return NaturalLanguageMemoryInterface(vector_store)


def process_nl_query(query: str, vector_store) -> Dict[str, any]:
    """
    Process a natural language query (convenience function)
    
    Args:
        query: Natural language query
        vector_store: VectorStore instance
        
    Returns:
        Operation result
    """
    interface = create_nl_interface(vector_store)
    return interface.process(query)
