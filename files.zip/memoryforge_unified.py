"""
MemoryForge-AI Unified System
Complete integration of all 4 phases into a single cohesive system
"""

from typing import Dict, List, Optional, Any
from pathlib import Path
import logging
from datetime import datetime

# Phase 1: Core memory system
from phase1_hybrid_memory.memory_models import MemoryEntry, MemoryMetadata, MemoryTier
from phase1_hybrid_memory.vector_store import VectorStore
from phase1_archival_complete import ArchivalPipeline, MemoryCompressor, ArchivalScheduler

# Phase 2: MCP Server (imported separately when running as server)
# from phase2_mcp_server_complete import mcp

# Phase 3: Content ingestion
from phase3_content_ingestion_complete import (
    ContentIngestionPipeline, ContentExtractor, batch_ingest_directory
)

# Phase 4: Natural language interface
from phase4_nl_interface_complete import NaturalLanguageMemoryInterface


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class MemoryForgeConfig:
    """Configuration for MemoryForge system"""
    
    def __init__(self,
                 data_directory: str = "./memoryforge_data",
                 token_limit: int = 190000,
                 archival_threshold_hours: float = 24.0,
                 token_pressure_threshold: float = 0.7,
                 compression_enabled: bool = True,
                 watch_directories: Optional[List[str]] = None):
        """
        Args:
            data_directory: Base directory for all data storage
            token_limit: Maximum token capacity
            archival_threshold_hours: Archive memories older than this
            token_pressure_threshold: Trigger archival at this pressure
            compression_enabled: Enable memory compression
            watch_directories: Directories to watch for content ingestion
        """
        self.data_directory = Path(data_directory)
        self.token_limit = token_limit
        self.archival_threshold_hours = archival_threshold_hours
        self.token_pressure_threshold = token_pressure_threshold
        self.compression_enabled = compression_enabled
        self.watch_directories = watch_directories or []
        
        # Create directories
        self.data_directory.mkdir(parents=True, exist_ok=True)
        self.chroma_db_path = self.data_directory / "chroma_db"
        self.logs_path = self.data_directory / "logs"
        self.uploads_path = self.data_directory / "uploads"
        
        for path in [self.chroma_db_path, self.logs_path, self.uploads_path]:
            path.mkdir(parents=True, exist_ok=True)


class MemoryForgeSystem:
    """
    Unified MemoryForge-AI System
    
    Integrates all 4 phases:
    - Phase 1: Hybrid memory with archival
    - Phase 2: MCP server interface
    - Phase 3: Content ingestion
    - Phase 4: Natural language processing
    """
    
    def __init__(self, config: Optional[MemoryForgeConfig] = None):
        """
        Initialize complete MemoryForge system
        
        Args:
            config: System configuration (uses defaults if None)
        """
        self.config = config or MemoryForgeConfig()
        logger.info(f"Initializing MemoryForge system at {self.config.data_directory}")
        
        # Phase 1: Initialize vector store and archival
        self.vector_store = VectorStore(
            persist_directory=str(self.config.chroma_db_path)
        )
        
        self.archival_pipeline = ArchivalPipeline(
            vector_store=self.vector_store,
            compressor=MemoryCompressor() if self.config.compression_enabled else None,
            scheduler=ArchivalScheduler(
                age_threshold_hours=self.config.archival_threshold_hours,
                token_pressure_threshold=self.config.token_pressure_threshold
            )
        )
        
        # Phase 3: Initialize content ingestion
        self.content_ingestion = ContentIngestionPipeline(
            vector_store=self.vector_store,
            watch_paths=self.config.watch_directories,
            extractor=ContentExtractor()
        )
        
        # Phase 4: Initialize NL interface
        self.nl_interface = NaturalLanguageMemoryInterface(
            vector_store=self.vector_store
        )
        
        self.current_token_usage = 0
        self.system_stats = {
            'started_at': datetime.now(),
            'total_operations': 0,
            'memories_added': 0,
            'searches_performed': 0,
            'archival_cycles': 0,
            'files_ingested': 0
        }
        
        logger.info("MemoryForge system initialized successfully")
    
    # ========================================================================
    # MEMORY OPERATIONS (Phase 1)
    # ========================================================================
    
    def add_memory(self, 
                   content: str,
                   topics: Optional[List[str]] = None,
                   tags: Optional[List[str]] = None,
                   importance: float = 0.5,
                   source: str = "api") -> str:
        """
        Add a new memory to the system
        
        Args:
            content: Memory content
            topics: Topics/categories
            tags: Tags for filtering
            importance: Importance score (0-1)
            source: Source identifier
            
        Returns:
            Memory ID
        """
        try:
            entry = MemoryEntry(
                content=content,
                metadata=MemoryMetadata(
                    topics=topics or [],
                    tags=tags or [],
                    importance_score=importance,
                    source=source
                )
            )
            
            memory_id = self.vector_store.add_memory(entry)
            self.system_stats['memories_added'] += 1
            self.system_stats['total_operations'] += 1
            
            # Estimate token usage (rough estimate)
            self.current_token_usage += len(content.split()) * 1.3
            
            logger.info(f"Added memory {memory_id[:8]}... from {source}")
            return memory_id
            
        except Exception as e:
            logger.error(f"Error adding memory: {e}")
            raise
    
    def search_memories(self,
                       query: str,
                       limit: int = 5,
                       min_similarity: float = 0.3) -> List[Dict[str, Any]]:
        """
        Search for relevant memories
        
        Args:
            query: Search query
            limit: Maximum results
            min_similarity: Minimum similarity threshold
            
        Returns:
            List of matching memories with scores
        """
        try:
            results = self.vector_store.search(query, limit=limit)
            
            # Filter and format results
            formatted_results = []
            for entry, score in results:
                if score >= min_similarity:
                    formatted_results.append({
                        'memory_id': entry.id,
                        'content': entry.content,
                        'similarity': round(score, 4),
                        'tier': entry.metadata.tier.value,
                        'topics': entry.metadata.topics,
                        'importance': entry.metadata.importance_score,
                        'created_at': entry.metadata.created_at.isoformat()
                    })
            
            self.system_stats['searches_performed'] += 1
            self.system_stats['total_operations'] += 1
            
            logger.info(f"Search '{query}' returned {len(formatted_results)} results")
            return formatted_results
            
        except Exception as e:
            logger.error(f"Error searching memories: {e}")
            raise
    
    def run_archival(self, force: bool = False) -> Dict[str, Any]:
        """
        Run automatic archival cycle
        
        Args:
            force: Force archival even if not needed
            
        Returns:
            Archival results
        """
        try:
            result = self.archival_pipeline.run_archival_cycle(
                current_token_usage=int(self.current_token_usage),
                token_limit=self.config.token_limit,
                compress=self.config.compression_enabled
            )
            
            if result['status'] == 'completed':
                self.system_stats['archival_cycles'] += 1
                self.current_token_usage = result.get('new_token_usage', self.current_token_usage)
            
            self.system_stats['total_operations'] += 1
            logger.info(f"Archival cycle: {result['status']}")
            
            return result
            
        except Exception as e:
            logger.error(f"Error running archival: {e}")
            raise
    
    # ========================================================================
    # CONTENT INGESTION (Phase 3)
    # ========================================================================
    
    def start_watching(self):
        """Start watching file system for content"""
        try:
            self.content_ingestion.start()
            logger.info("Content ingestion started")
        except Exception as e:
            logger.error(f"Error starting content ingestion: {e}")
            raise
    
    def stop_watching(self):
        """Stop watching file system"""
        try:
            self.content_ingestion.stop()
            logger.info("Content ingestion stopped")
        except Exception as e:
            logger.error(f"Error stopping content ingestion: {e}")
            raise
    
    def ingest_directory(self, directory: str, recursive: bool = True) -> Dict[str, Any]:
        """
        Batch ingest all files from a directory
        
        Args:
            directory: Directory path
            recursive: Recurse into subdirectories
            
        Returns:
            Ingestion statistics
        """
        try:
            stats = batch_ingest_directory(
                directory=directory,
                vector_store=self.vector_store,
                recursive=recursive
            )
            
            self.system_stats['files_ingested'] += stats.get('processed', 0)
            self.system_stats['total_operations'] += 1
            
            logger.info(f"Ingested {stats.get('processed', 0)} files from {directory}")
            return stats
            
        except Exception as e:
            logger.error(f"Error ingesting directory: {e}")
            raise
    
    # ========================================================================
    # NATURAL LANGUAGE INTERFACE (Phase 4)
    # ========================================================================
    
    def process_nl_query(self, query: str) -> Dict[str, Any]:
        """
        Process natural language query
        
        Args:
            query: Natural language query
            
        Returns:
            Query result
        """
        try:
            result = self.nl_interface.process(query)
            self.system_stats['total_operations'] += 1
            
            logger.info(f"NL query: '{query}' -> {result['parsed']['intent']}")
            return result
            
        except Exception as e:
            logger.error(f"Error processing NL query: {e}")
            raise
    
    # ========================================================================
    # SYSTEM MANAGEMENT
    # ========================================================================
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        try:
            memory_stats = self.vector_store.get_stats()
            ingestion_stats = self.content_ingestion.get_stats()
            archival_stats = self.archival_pipeline.get_pipeline_stats()
            nl_stats = self.nl_interface.get_stats()
            
            status = {
                'system': {
                    'uptime': str(datetime.now() - self.system_stats['started_at']),
                    'total_operations': self.system_stats['total_operations'],
                    'token_usage': int(self.current_token_usage),
                    'token_limit': self.config.token_limit,
                    'token_pressure': round(self.current_token_usage / self.config.token_limit, 3)
                },
                'memory': memory_stats,
                'ingestion': ingestion_stats,
                'archival': archival_stats,
                'nl_interface': nl_stats,
                'stats': self.system_stats
            }
            
            return status
            
        except Exception as e:
            logger.error(f"Error getting system status: {e}")
            raise
    
    def shutdown(self):
        """Gracefully shutdown the system"""
        logger.info("Shutting down MemoryForge system...")
        
        try:
            self.stop_watching()
        except:
            pass
        
        logger.info("MemoryForge system shutdown complete")


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def create_system(data_directory: str = "./memoryforge_data",
                 watch_directories: Optional[List[str]] = None) -> MemoryForgeSystem:
    """
    Create a MemoryForge system with default configuration
    
    Args:
        data_directory: Base data directory
        watch_directories: Directories to watch
        
    Returns:
        Configured MemoryForge system
    """
    config = MemoryForgeConfig(
        data_directory=data_directory,
        watch_directories=watch_directories
    )
    return MemoryForgeSystem(config)


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    # Create system
    system = create_system(
        data_directory="./demo_memoryforge",
        watch_directories=["./demo_documents"]
    )
    
    # Example 1: Add memories via API
    print("\n1. Adding memories...")
    memory_id = system.add_memory(
        content="Python is a high-level programming language",
        topics=["programming", "python"],
        importance=0.8
    )
    print(f"   Added memory: {memory_id[:8]}...")
    
    # Example 2: Search memories
    print("\n2. Searching memories...")
    results = system.search_memories("programming language", limit=3)
    for result in results:
        print(f"   - {result['content'][:50]}... (similarity: {result['similarity']})")
    
    # Example 3: Natural language interface
    print("\n3. Using natural language...")
    result = system.process_nl_query("Remember that TensorFlow is a machine learning library")
    print(f"   {result['message']}")
    
    result = system.process_nl_query("What do you know about machine learning?")
    print(f"   {result['message']}")
    
    # Example 4: Batch ingest directory
    print("\n4. Ingesting directory...")
    # stats = system.ingest_directory("./demo_documents")
    # print(f"   Ingested {stats['processed']} files")
    
    # Example 5: Run archival
    print("\n5. Running archival...")
    archival_result = system.run_archival()
    print(f"   Archival status: {archival_result['status']}")
    
    # Example 6: Get system status
    print("\n6. System status:")
    status = system.get_system_status()
    print(f"   Total operations: {status['system']['total_operations']}")
    print(f"   Token usage: {status['system']['token_usage']}/{status['system']['token_limit']}")
    print(f"   Memory count: {status['memory']['total_count']}")
    print(f"   Tier 1: {status['memory']['tier1_count']}, Tier 2: {status['memory']['tier2_count']}")
    
    # Shutdown
    system.shutdown()
    
    print("\n✅ Demo complete!")
